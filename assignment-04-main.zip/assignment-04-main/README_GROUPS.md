# Assignment 04

* Group 1: aguh, ojoh, annro
* Group 2: laku, tosp, kmsa
* Group 3: mlth, nkar, oljh
* Group 4: jwni, dadh, mbia
* Group 5: otja, maxt, luel
* Group 6: clly, frai, jric
* Group 7: emkh, tuho, luha
* Group 8: siar, gues, adjr
* Group 9: tcla, adrka, bemi
* Group 10: kmey, wihe, laup
* Group 11: json, nkrj, weny
* Group 12: mfjo, malsc, tbav
* Group 13: rasni, elbr, jklo
* Group 14: tbru, kbej, hast
* Group 15: mreh, nicha, mgan
* Group 16: brml, phimo, chbl
* Group 17: frgm, frhc, avia
* Group 18: fefa, vist, asly
* Group 19: ehel, monha, jakst
* Group 20: labp, nlje, bhag
* Group 21: hecn, behv, aarv
* Group 22: frepe, nihp, siol
* Group 23: lufr, tuka, tokj
* Group 24: emtj, mwha, biha
* Group 25: amdh, mbjn, selb
* Group 26: dlha, jawb, ssbo
* Group 27: unla, bath, midf
* Group 28: eikb, atro, asjo
* Group 29: phla, mbln, mhvl
* Group 30: crco, okre, raoo
* Group 31: emno, rogy, skas
* Group 32: jacg, hcan, mhsi
* Group 33: rakt, lawu, memr
* Group 34: ahad, sibh, stmp
* Group 35: base, mesv, aing
* Group 36: vime, mroa, erja
* Group 37: rafa, jouj, aldy
* Group 38: lanr, pekp, shho, olfw
* Group 39: clwj, nsel, paab, oska
* Group 40: jown, aegr, tael
* Group 41: jevb, millh, teim
* Group 42: shad, seel, reer
* Group 43: asgm, nidd, omac
* Group 44: ksig, timj, esmi
* Group 45: husa, noms
