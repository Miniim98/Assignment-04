namespace Assignment.Infrastructure;

public class WorkItemRepository
{
}
