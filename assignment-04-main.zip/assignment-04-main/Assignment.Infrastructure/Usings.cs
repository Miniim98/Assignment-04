global using Microsoft.EntityFrameworkCore;
global using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
global using System.ComponentModel.DataAnnotations;

global using Assignment.Core;
