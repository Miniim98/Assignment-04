namespace Assignment.Infrastructure;

public class TagRepository
{
}
