namespace Assignment.Infrastructure;

public class UserRepository
{
}
