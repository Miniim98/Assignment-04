namespace Assignment.Infrastructure.Tests;

public class WorkItemRepositoryTests
{
}
