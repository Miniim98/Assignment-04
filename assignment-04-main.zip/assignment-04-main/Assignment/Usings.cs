global using Assignment;
