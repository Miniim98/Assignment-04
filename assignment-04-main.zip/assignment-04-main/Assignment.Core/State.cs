﻿namespace Assignment.Core;

public enum State
{
    New,
    Active,
    Resolved,
    Closed,
    Removed
}
